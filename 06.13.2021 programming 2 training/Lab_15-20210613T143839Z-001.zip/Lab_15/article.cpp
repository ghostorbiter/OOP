#include <iostream> 
using namespace std;
#include <iomanip>
#include <string>
#include "article.h"

/*
ostream& operator<<(ostream& out, const article& a)
{
	a.info(out);
	return out;
}
*/

// implement