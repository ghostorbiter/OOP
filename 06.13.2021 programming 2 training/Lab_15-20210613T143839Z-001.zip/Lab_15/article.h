#pragma once
#include <iostream> 
using namespace std; 
#include <iomanip>
#include <string>

class article
{
protected:
	string name;
	
public:
	article(string name) : name(name) {}
	virtual ~article() {}
	virtual double value() const = 0;
	virtual ostream& info(ostream& out) const = 0;
	friend ostream& operator<<(ostream& out, const article& a);
};


class article_per_item : public article
{
protected:
	double price_per_item;

public:
	// implement


};


class article_per_kilo : public article
{
protected:
	double price_per_kilo;
	double weight;

public:
	// implement


};


