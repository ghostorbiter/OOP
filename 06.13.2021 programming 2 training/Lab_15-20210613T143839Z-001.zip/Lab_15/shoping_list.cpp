#include <iostream> 
using namespace std; 
#include <fstream>
#include <algorithm>
#include <numeric>
#include "shoping_list.h"
#include "article.h"

// implement