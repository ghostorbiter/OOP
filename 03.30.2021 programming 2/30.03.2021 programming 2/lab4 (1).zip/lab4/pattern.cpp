#include "pattern.h"
#include "card.h"

pattern::pattern(int sx, element el)
{
	this->sx = sx;
	this->el = el;
}

void pattern::paint(card& c) const
{
	for (int i = 0; i < c.size(); i += 2)
	{
		c(this->sx, i) = this->el;
	}
}
