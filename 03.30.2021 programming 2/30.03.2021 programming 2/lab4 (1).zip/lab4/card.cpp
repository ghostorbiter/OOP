#include <iostream>
using namespace std;
#include "card.h"
#include "pattern.h"

void card::init(int _m, element el, element* tab)
{
	this->m = _m;

	int size = m * m;

	this->t = new element[size];

	if (this->t == nullptr)
	{
		this->m = 0;
		return;
	}

	if (tab != nullptr)
	{
		for (int i = 0 ; i < size; i++)
		{
			this->t[i] = tab[i];
		}
	}
	else
	{
		for (int i = 0; i < size; i++)
		{
			this->t[i] = el;
		}
	}
}

card::card(int m, element el)
{
	this->init(m, el);
}

card::card(const card& k)
{
	this->init(k.m, element{}, k.t);
}

card& card::operator=(const card& c)
{
	if (this != &c)
	{
		delete[] this->t;
		this->init(c.m, element{}, c.t);
	}
	return *this;
}

int card::size() const
{
	return this->m;
}

card& card::operator+=(const pattern& g)
{
	g.paint(*this);
	return (*this);
}

void card::egg(element el)
{
	int sx = m / 2;
	int sy = m / 2;
	int r = min(sx, sy) - 1;

	for (int i = 0; i < this->m; i++)
	{
		for (int j = 0; j < this->m; j++)
		{
			if ((i - sx) * (i - sx) + (j - sy) * (j - sy) > r * r)
			{
				(*this)(i, j) = el;
			}
		}
	}
}

ostream& operator<<(ostream& out, const card& k)
{
	for (int i = 0; i < k.m; i++)
	{
		for (int j = 0; j < k.m; j++)
		{
			out << k(i, j);
		}
		out << endl;
	}
	return out;
}
