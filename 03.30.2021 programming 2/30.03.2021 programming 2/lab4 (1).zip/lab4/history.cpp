#include "history.h"

history::history(const card& c)
{
	this->h[0] = c;
	this->num = 1;
}

void history::write(const card& c)
{
	if (this->num == n)
	{
		for (int i = 0; i < n - 1; i++)
		{
			this->h[i] = h[i + 1];
		}
		this->num--;
	}

	this->h[this->num] = c;
	this->num++;
}

card history::undo()
{
	if (this->num == 1)
	{
		return h[0];
	}

	this->num--;

	return this->h[this->num - 1];
}
