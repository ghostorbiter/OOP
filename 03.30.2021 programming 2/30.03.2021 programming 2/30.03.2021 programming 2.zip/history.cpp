#include "history.h"

history::history(const card& c) {	// right at the beginning we enter the current picture in the history (index 0)
	if (!num || num == 0) {
		h[0] = c;
		num = 1;
	}
	if (num == n) {
		delete[] &h[0];
		for (int i = 0; i < n - 1; i++) {
			h[i] = h[i + 1];
		}
		h[n-1] = c;
	}
	if (num < 0 || num > n)
	{
		num = 0;
		for (int i = 0; i < n - 1; i++) {
			delete[] &h[i];
		}
	}
	else {
		h[num - 1] = c;
		num++;
	}
}

void history::write(const card& c)
{
	cout << c;
}

card history::undo()
{
	if (num == 1) {
		return h[0];
	}
	num--;
	return h[num];
}
// if we only have 1 card in the history (num == 1), we return it
// otherwise we return one before last
// (there is always at least 1 picture left in the history)