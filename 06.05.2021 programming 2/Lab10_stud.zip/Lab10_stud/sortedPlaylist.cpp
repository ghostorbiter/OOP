#include <iostream>
#include "sortedPlaylist.h"
using namespace std;

//**********************STAGE 5**********************