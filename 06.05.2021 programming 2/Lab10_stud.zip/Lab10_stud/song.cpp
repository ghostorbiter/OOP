#include <iostream>
#include "song.h"
using namespace std;

//**********************STAGE 1**********************