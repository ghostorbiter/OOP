#include <iostream>
#include <string>
#include <algorithm>
#include <numeric>
#include <set>
#include "Workplace.h"
using namespace std;


