#pragma once
#include <string>
#include <list>
#include <map>
#include "Employee.h"

using namespace std;


class Workplace
{
private:
    list<Employee> employees;

public:
    bool AddEmployee(Employee e);
    bool AddEmployee();
    void SortByName();
    Employee MaxSalary() const;
    void RemoveSalaryAbove(int lim);
    void meanSalary(string position) const;
    map<string, double> salaryEqualization() const;
    friend ostream& operator<<(ostream& out, const Workplace& w);

 };



