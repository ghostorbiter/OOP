#include <queue>
#include <stdexcept>
#include "cartographer.hpp"
using namespace std;


void Cartographer::clearPath()
{
	auto i = [](TerrainState& a) {
		if (a == TerrainState::Visited)
			a = TerrainState::Accessible;
	};

	for_each(positions.begin(), positions.end(), i);
}

bool Cartographer::findRoute(int x, int y, int finishx, int finishy)
{
	if (is_x_inRange(x) && is_y_inRange(y) && is_x_inRange(finishx) && is_y_inRange(finishy)) {
		candidates.push(make_pair(x, y));

		int dir[4][2] = { {1,0}, {-1,0}, {0,1}, {0,-1} };

		while (candidates.size() > 0) {
			pair<int, int> p = candidates.front();
			candidates.pop();

			if ((p.second * cols + p.first) < (cols * rows))
				positions[p.second * cols + p.first] = TerrainState::Visited;

			if (p == make_pair(finishx, finishy))
				return true;

			for (int i = 0; i < 4; i++) {
				int a = p.first + dir[i][0];
				int b = p.second + dir[i][1];

				if (a >= 0 && b >= 0 && a < cols && b < rows && ((b * cols + a) < (rows * cols)) && positions[b * cols + a] != TerrainState::Inaccessible && positions[b * cols + a] != TerrainState::Visited) {
					candidates.push(make_pair(a, b));
				}
			}
		}
	}
	clearPath();
	return false;
}