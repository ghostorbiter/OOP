#ifndef __CARTOGRAPHER__
#define __CARTOGRAPHER__

#include <vector>
#include "terrain_map.hpp"
using namespace std;

// Part 4
// Class Cartographer

// TO DO



#endif
