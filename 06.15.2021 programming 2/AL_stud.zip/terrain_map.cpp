#include <stdexcept>
#include <algorithm>
#include "terrain_map.hpp"
using namespace std;
