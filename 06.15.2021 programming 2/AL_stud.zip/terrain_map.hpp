#ifndef __TERRAIN_MAP__
#define __TERRAIN_MAP__

#include <vector>
#include <iostream>

#include "map_interface.hpp"
using namespace std;

class TerrainMap : public MapInterface {
protected:
    // Part 1
    enum class TerrainState{ Inaccessible, Accessible, Visited };
    int cols;
    int rows;
    vector<TerrainState> positions;
    
public:
    // Part 1
    
    // TO DO


    // Part 2
    //void setVisited(int x, int y);
    //int visitedCount() const;


    // Part 3
    //TerrainMap& operator!();

};


#endif
