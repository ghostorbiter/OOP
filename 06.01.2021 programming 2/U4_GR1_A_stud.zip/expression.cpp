#include <iostream>
#include <string>
#include "expression.h"
using namespace std;

expression::expression() : symbol(""), priority(0)
{
	type = expression_type::constant;
}

expression::expression(string element) : symbol(element), priority(0)
{
	if (element == "(" || element == ")")
	{
		priority = 1; type = expression_type::bracket;
	}
	else if (element == "+" || element == "-")
	{
		priority = 2;  type = expression_type::math_operator;
	}
	else if (element == "*" || element == "/")
	{
		priority = 3; type = expression_type::math_operator;
	}
	else
	{
		type = expression_type::constant;
	}
}

// Stage 1 
//TO DO

