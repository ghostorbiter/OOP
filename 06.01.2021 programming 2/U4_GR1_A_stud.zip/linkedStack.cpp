#include <iostream>
#include "linkedStack.h"
#include "stackADT.h"
using namespace std;

//Default constructor
linkedStack::linkedStack()
{
    stackTop = NULL;
}


bool linkedStack::isEmptyStack() const
{
    return(stackTop == NULL);
} //end isEmptyStack


bool linkedStack::isFullStack() const
{
    return false;
} //end isFullStack


void linkedStack::initializeStack()
{
    nodeType* temp; //pointer to delete the node

    while (stackTop != NULL)  //while there are elements in 
                              //the stack
    {
        temp = stackTop;    //set temp to point to the 
                            //current node
        stackTop = stackTop->link;  //advance stackTop to the
                                    //next node
        delete temp;    //deallocate memory occupied by temp
    }
} //end initializeStack



void linkedStack::push(const int& newElement)
{
    nodeType* newNode;  //pointer to create the new node

    newNode = new nodeType; //create the node

    newNode->info = newElement; //store newElement in the node
    newNode->link = stackTop; //insert newNode before stackTop
    stackTop = newNode;       //set stackTop to point to the 
                              //top node
} //end push



int linkedStack::top() const
{
    assert(stackTop != NULL); //if stack is empty,
                              //terminate the program
    return stackTop->info;    //return the top element 
}//end top


void linkedStack::pop()
{
    nodeType* temp;   //pointer to deallocate memory

    if (stackTop != NULL)
    {
        temp = stackTop;  //set temp to point to the top node

        stackTop = stackTop->link;  //advance stackTop to the 
                                    //next node
        delete temp;    //delete the top node
    }
    else
        cout << "Cannot remove from an empty stack." << endl;
}//end pop


void linkedStack::copyStack(const linkedStack& otherStack)
{
    nodeType* newNode, * current, * last;

    if (stackTop != NULL) //if stack is nonempty, make it empty
        initializeStack();

    if (otherStack.stackTop == NULL)
        stackTop = NULL;
    else
    {
        current = otherStack.stackTop;  //set current to point
                                   //to the stack to be copied

            //copy the stackTop element of the stack 
        stackTop = new nodeType;  //create the node

        stackTop->info = current->info; //copy the info
        stackTop->link = NULL;  //set the link field of the
                                //node to NULL
        last = stackTop;        //set last to point to the node
        current = current->link;    //set current to point to
                                    //the next node

            //copy the remaining stack
        while (current != NULL)
        {
            newNode = new nodeType;

            newNode->info = current->info;
            newNode->link = NULL;
            last->link = newNode;
            last = newNode;
            current = current->link;
        }//end while
    }//end else
} //end copyStack

//copy constructor
linkedStack::linkedStack(
    const linkedStack& otherStack)
{
    stackTop = NULL;
    copyStack(otherStack);
}//end copy constructor

//destructor
linkedStack::~linkedStack()
{
    initializeStack();
}//end destructor

//overloading the assignment operator

const linkedStack& linkedStack::operator=(const linkedStack& otherStack)
{
    if (this != &otherStack) //avoid self-copy
        copyStack(otherStack);

    return *this;
}//end operator=


ostream& operator<<(ostream& out, const linkedStack& ls)
{
    if (ls.isEmptyStack())
        out << "Stack is empty" << endl;
    else {
        nodeType* tmpNode = ls.stackTop;
        while (tmpNode != nullptr)
        {
            out << tmpNode->info << endl;
            tmpNode = tmpNode->link;
        }
    }
    return out;
}