#pragma once

class Date
{
	int day;
	int month;
	int year;
	
	bool format;

	bool ifLeep() const;

public:
	

};



