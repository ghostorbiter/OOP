#include <iostream>
using namespace std;
#include <iomanip>
#include "date.h"

const int M = 12;	//number of months
static int dl[M] = { 31,28,31,30,31,30,31,31,30,31,30,31 };

